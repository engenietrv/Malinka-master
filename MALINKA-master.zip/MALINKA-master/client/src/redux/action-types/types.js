/* eslint-disable import/prefer-default-export */
const ADD_PIN_SETTINGS = 'ADD_PIN_SETTINGS';
const ADD_HOMES = 'ADD_HOMES';

export {
  ADD_PIN_SETTINGS,
  ADD_HOMES,
};
